const attributes = {
};

export default attributes;