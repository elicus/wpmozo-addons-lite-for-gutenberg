import "./blocks/before-after-slider/js/index.js";
import "./blocks/content-toggle/js/index.js";
import "./blocks/content-wraper/js/index.js";
import "./blocks/fancy-heading/js/index.js";